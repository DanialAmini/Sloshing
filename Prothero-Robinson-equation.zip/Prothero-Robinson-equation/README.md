# Prothero-Robinson-equation
Prothero-Robinson equation is a sitff ODE whih is used as a benchmark problem for testing various time marching methods such as various Runge-Kutta schemes.
