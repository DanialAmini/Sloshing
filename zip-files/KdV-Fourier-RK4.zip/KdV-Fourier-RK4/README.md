# KdV-Fourier-RK4
Solving KdV equation with Fourier series as spatial discretization, Runge-Kutta 4th order for time marching, and trapezoidal integration rule
