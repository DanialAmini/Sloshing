# standing-2
files  	sage_notebook_22.ipynb and  	sage_notebook_23.ipynb show the calculation of coefficients for orders 1-5 with and without simplifying assumptions. coefficients are calculated by integrating the expressions to find Fourier series. 

sage_file2.ipynb uses simplification into multiple angle functions without integration, without any assumptions on coeffients.

sage_odd.ipynb and sage_even.ipynb files directly make use of form & patterns for coefficients for even and odd orders, and the coefficients are calculated with integration. 

