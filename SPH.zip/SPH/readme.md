# SPH-testing-B-Spline-Kernel
SPH-testing-B-Spline-Kernel

opctave file made in june 2019, when I was trying to get into georgewash but didn't :(
